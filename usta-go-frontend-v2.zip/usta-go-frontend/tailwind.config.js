/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'usta': {
          'navy': '#1E3A8A',
          'purple': '#3730A3',
          'blue': '#3B82F6',
          'violet': '#7C3AED',
          'orange': '#FF6B35',
          'card': '#2D3748',
          'green': '#10B981',
          'yellow': '#FCD34D',
          'red': '#EF4444',
        }
      },
      backgroundImage: {
        'gradient-main': 'linear-gradient(to bottom, #1E3A8A, #3730A3)',
        'gradient-button': 'linear-gradient(to right, #3B82F6, #7C3AED)',
        'gradient-card': 'linear-gradient(135deg, #3B82F6 0%, #7C3AED 100%)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in',
        'slide-up': 'slideUp 0.3s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        }
      }
    },
  },
  plugins: [],
}
