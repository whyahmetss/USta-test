import React, { useState } from 'react';
import { ChevronLeft, MapPin, Clock, Phone, MessageCircle, Star, CheckCircle, AlertTriangle } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';

const JobDetailPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [showCancelModal, setShowCancelModal] = useState(false);

  // Mock data - gerçekte backend'den gelecek
  const job = {
    id: id,
    title: 'Priz Tamiri',
    category: 'Elektrikçi',
    status: 'Yolda',
    statusColor: 'orange',
    description: 'Salondaki 3 adet prizin çalışmıyor. Acil olarak tamir edilmesi gerekiyor. Sigorta atması var.',
    date: 'Bugün, 15:30',
    createdDate: '13 Şubat 2026, 12:00',
    address: 'Kadıköy Mah. Bahariye Cad. No:45 D:8',
    district: 'Kadıköy, İstanbul',
    price: '250 TL',
    priceBreakdown: {
      labor: '150 TL',
      material: '80 TL',
      service: '20 TL'
    },
    usta: {
      name: 'Mehmet Yılmaz',
      rating: 4.8,
      completedJobs: 247,
      phone: '+90 532 123 45 67',
      photo: 'https://i.pravatar.cc/150?img=33',
      specialties: ['Priz', 'Anahtar', 'Sigorta']
    },
    timeline: [
      { status: 'İş Oluşturuldu', time: '12:00', completed: true },
      { status: 'Usta Kabul Etti', time: '12:15', completed: true },
      { status: 'Yola Çıktı', time: '15:00', completed: true },
      { status: 'Adrese Vardı', time: '-', completed: false },
      { status: 'İşe Başladı', time: '-', completed: false },
      { status: 'Tamamlandı', time: '-', completed: false }
    ],
    photos: [
      'https://images.unsplash.com/photo-1621905252472-5b5e6f3b42e4?w=300',
      'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=300'
    ]
  };

  const handleCancelJob = () => {
    setShowCancelModal(true);
  };

  const confirmCancel = () => {
    // Backend'e cancel isteği gönderilecek
    setShowCancelModal(false);
    navigate('/jobs');
  };

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-4 pt-12 pb-6 sticky top-0 bg-gradient-main z-10 backdrop-blur-xl bg-opacity-95">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/jobs')}
            className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center"
          >
            <ChevronLeft size={24} />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold">{job.title}</h1>
            <p className="text-sm text-gray-400">{job.category}</p>
          </div>
          <span className={`px-4 py-2 rounded-xl text-xs font-semibold ${
            job.statusColor === 'orange' ? 'bg-usta-orange/20 text-usta-orange animate-pulse-slow' :
            job.statusColor === 'green' ? 'bg-usta-green/20 text-usta-green' :
            'bg-usta-yellow/20 text-usta-yellow'
          }`}>
            {job.status}
          </span>
        </div>
      </header>

      {/* Photos */}
      {job.photos && job.photos.length > 0 && (
        <div className="px-4 mb-6">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide">
            {job.photos.map((photo, index) => (
              <div key={index} className="min-w-[200px] h-32 rounded-2xl overflow-hidden">
                <img src={photo} alt={`İş fotoğrafı ${index + 1}`} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Usta Card */}
      <div className="px-4 mb-6">
        <h3 className="text-lg font-bold mb-3">Usta Bilgileri</h3>
        <div className="card-dark p-4">
          <div className="flex items-center gap-4 mb-4">
            <img 
              src={job.usta.photo} 
              alt={job.usta.name}
              className="w-16 h-16 rounded-full object-cover"
            />
            <div className="flex-1">
              <h4 className="font-bold text-lg">{job.usta.name}</h4>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Star size={14} className="text-usta-yellow fill-usta-yellow" />
                <span>{job.usta.rating}</span>
                <span>•</span>
                <span>{job.usta.completedJobs} iş</span>
              </div>
            </div>
          </div>

          {/* Specialties */}
          <div className="flex gap-2 mb-4 flex-wrap">
            {job.usta.specialties.map((specialty, index) => (
              <span key={index} className="bg-usta-blue/20 text-usta-blue px-3 py-1 rounded-lg text-xs font-semibold">
                {specialty}
              </span>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <a 
              href={`tel:${job.usta.phone}`}
              className="flex-1 bg-usta-green/20 text-usta-green py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-usta-green/30 transition-colors"
            >
              <Phone size={20} />
              Ara
            </a>
            <button 
              onClick={() => navigate(`/messages/${job.usta.name}`)}
              className="flex-1 bg-usta-blue/20 text-usta-blue py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-usta-blue/30 transition-colors"
            >
              <MessageCircle size={20} />
              Mesaj
            </button>
          </div>
        </div>
      </div>

      {/* Job Details */}
      <div className="px-4 mb-6">
        <h3 className="text-lg font-bold mb-3">İş Detayları</h3>
        <div className="card-dark p-4 space-y-4">
          <div>
            <label className="text-sm text-gray-400 block mb-1">Açıklama</label>
            <p className="text-white">{job.description}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-gray-400 block mb-1">Tarih & Saat</label>
              <div className="flex items-center gap-2 text-white">
                <Clock size={16} className="text-usta-blue" />
                <span className="text-sm">{job.date}</span>
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-1">Oluşturulma</label>
              <span className="text-sm text-white">{job.createdDate}</span>
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-400 block mb-1">Adres</label>
            <div className="flex items-start gap-2">
              <MapPin size={16} className="text-usta-blue mt-1" />
              <div>
                <p className="text-white text-sm">{job.address}</p>
                <p className="text-gray-400 text-xs">{job.district}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="px-4 mb-6">
        <h3 className="text-lg font-bold mb-3">İş Akışı</h3>
        <div className="card-dark p-4">
          {job.timeline.map((step, index) => (
            <div key={index} className="flex items-start gap-4 pb-4 last:pb-0">
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step.completed ? 'bg-usta-green' : 'bg-gray-700'
                }`}>
                  {step.completed && <CheckCircle size={16} />}
                </div>
                {index < job.timeline.length - 1 && (
                  <div className={`w-0.5 h-8 ${step.completed ? 'bg-usta-green' : 'bg-gray-700'}`}></div>
                )}
              </div>
              <div className="flex-1 pt-1">
                <p className={`font-semibold ${step.completed ? 'text-white' : 'text-gray-500'}`}>
                  {step.status}
                </p>
                <p className="text-xs text-gray-400">{step.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Price Breakdown */}
      <div className="px-4 mb-6">
        <h3 className="text-lg font-bold mb-3">Fiyat Detayı</h3>
        <div className="card-dark p-4 space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">İşçilik</span>
            <span className="font-semibold">{job.priceBreakdown.labor}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Malzeme</span>
            <span className="font-semibold">{job.priceBreakdown.material}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Hizmet Bedeli</span>
            <span className="font-semibold">{job.priceBreakdown.service}</span>
          </div>
          <div className="border-t border-gray-700 pt-3 flex justify-between">
            <span className="font-bold text-lg">Toplam</span>
            <span className="font-bold text-2xl text-usta-blue">{job.price}</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      {job.status !== 'Tamamlandı' && job.status !== 'İptal Edildi' && (
        <div className="px-4 mb-6">
          <button 
            onClick={handleCancelJob}
            className="w-full bg-usta-red/20 text-usta-red py-4 rounded-2xl font-bold hover:bg-usta-red/30 transition-colors flex items-center justify-center gap-2"
          >
            <AlertTriangle size={20} />
            İptal Et
          </button>
        </div>
      )}

      {/* Cancel Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="card-dark p-6 max-w-sm w-full animate-slide-up">
            <h3 className="text-xl font-bold mb-4">İşi İptal Et</h3>
            <p className="text-gray-300 mb-6">
              Bu işi iptal etmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowCancelModal(false)}
                className="flex-1 btn-secondary py-3"
              >
                Vazgeç
              </button>
              <button 
                onClick={confirmCancel}
                className="flex-1 bg-usta-red text-white py-3 rounded-xl font-bold hover:bg-red-600 transition-colors"
              >
                İptal Et
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobDetailPage;
