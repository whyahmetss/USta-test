import React from 'react';
import { Search, Sliders, Zap, Wrench, Hammer, Sparkles, Paintbrush, Wind, ChevronRight, Star, MapPin, Clock } from 'lucide-react';

const HomePage = () => {
  const categories = [
    { id: 1, name: 'Elektrikçi', icon: Zap, color: 'text-usta-yellow', bgColor: 'bg-yellow-500/20' },
    { id: 2, name: 'Tesisatçı', icon: Wrench, color: 'text-usta-blue', bgColor: 'bg-blue-500/20' },
    { id: 3, name: 'Tadilat', icon: Hammer, color: 'text-usta-orange', bgColor: 'bg-orange-500/20' },
    { id: 4, name: 'Temizlik', icon: Sparkles, color: 'text-usta-green', bgColor: 'bg-green-500/20' },
    { id: 5, name: 'Boyacı', icon: Paintbrush, color: 'text-usta-violet', bgColor: 'bg-purple-500/20' },
    { id: 6, name: 'Klima', icon: Wind, color: 'text-cyan-400', bgColor: 'bg-cyan-500/20' },
  ];

  const popularServices = [
    {
      id: 1,
      title: 'Klima Bakımı',
      usta: 'Mehmet Yılmaz',
      rating: 4.8,
      price: '400-600 TL',
      image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400',
      badge: 'Hızlı Yanıt'
    },
    {
      id: 2,
      title: 'Priz Değişimi',
      usta: 'Ahmet Kaya',
      rating: 4.9,
      price: '200-350 TL',
      image: 'https://images.unsplash.com/photo-1621905252472-5b5e6f3b42e4?w=400'
    },
    {
      id: 3,
      title: 'Su Kaçağı Tamiri',
      usta: 'Ali Demir',
      rating: 5.0,
      price: '500-800 TL',
      image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400',
      badge: 'Popüler'
    }
  ];

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-4 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-button rounded-2xl flex items-center justify-center font-bold text-xl">
              UG
            </div>
            <h1 className="text-2xl font-bold">Usta Go</h1>
          </div>
          <div className="flex items-center gap-4">
            <button className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center">
              <Search size={20} />
            </button>
            <button className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center relative">
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-usta-orange rounded-full"></div>
              <span className="text-xl">🔔</span>
            </button>
            <button className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center">
              <div className="flex flex-col gap-1">
                <div className="w-4 h-0.5 bg-white"></div>
                <div className="w-4 h-0.5 bg-white"></div>
                <div className="w-4 h-0.5 bg-white"></div>
              </div>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <div className="px-4 mb-6 animate-fade-in">
        <div className="relative bg-gradient-card rounded-3xl p-6 overflow-hidden shadow-2xl">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-3xl">🔥</span>
              <span className="text-usta-yellow font-bold text-lg">20% İndirim</span>
            </div>
            <h2 className="text-2xl font-bold mb-2">İlk Siparişinizde!</h2>
            <p className="text-white/80 text-sm mb-4">
              Hemen kayıt olun, profesyonel hizmet alın
            </p>
            <button className="bg-usta-orange hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-xl transition-all">
              Hemen Başla
            </button>
          </div>
          <div className="absolute right-0 top-0 opacity-20">
            <span className="text-9xl">👷</span>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-4 mb-6 animate-slide-up">
        <div className="card-dark p-4 flex items-center gap-3">
          <Search className="text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Hangi hizmete ihtiyacınız var?"
            className="flex-1 bg-transparent outline-none text-white placeholder-gray-400"
          />
          <button className="w-10 h-10 rounded-xl bg-usta-blue/20 flex items-center justify-center hover:bg-usta-blue/30 transition-colors">
            <Sliders size={20} className="text-usta-blue" />
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 mb-8 animate-slide-up" style={{ animationDelay: '0.1s' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">Kategoriler</h3>
          <button className="flex items-center gap-1 text-usta-blue text-sm font-semibold">
            Tümünü Gör
            <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {categories.map((category, index) => (
            <div
              key={category.id}
              className="category-card text-center animate-fade-in"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div className={`w-16 h-16 mx-auto mb-3 rounded-2xl ${category.bgColor} flex items-center justify-center`}>
                <category.icon size={32} className={category.color} />
              </div>
              <p className="text-sm font-semibold">{category.name}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Popular Services */}
      <div className="px-4 mb-8 animate-slide-up" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">Popüler Hizmetler</h3>
          <button className="flex items-center gap-1 text-usta-blue text-sm font-semibold">
            Tümünü Gör
            <ChevronRight size={16} />
          </button>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
          {popularServices.map((service) => (
            <div
              key={service.id}
              className="min-w-[280px] card-dark rounded-2xl overflow-hidden hover:shadow-2xl transition-all cursor-pointer"
            >
              <div className="relative h-32">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="absolute top-3 left-3">
                  <h4 className="text-white font-bold">{service.title}</h4>
                </div>
                {service.badge && (
                  <div className="absolute top-3 right-3">
                    <span className="bg-usta-green text-white text-xs px-3 py-1 rounded-full font-semibold">
                      {service.badge}
                    </span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-button"></div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{service.usta}</p>
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-usta-yellow fill-usta-yellow" />
                      <span className="text-sm text-gray-300">{service.rating}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-usta-blue font-bold">{service.price}</span>
                  <button className="bg-usta-blue/20 text-usta-blue px-4 py-2 rounded-xl text-sm font-semibold hover:bg-usta-blue/30 transition-colors">
                    Detay
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Jobs */}
      <div className="px-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
        <h3 className="text-xl font-bold mb-4">Devam Eden İşler</h3>
        <div className="card-dark p-4 border-l-4 border-usta-blue">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-usta-blue/20 flex items-center justify-center">
              <Zap className="text-usta-yellow" size={24} />
            </div>
            <div className="flex-1">
              <h4 className="font-bold mb-1">Priz Tamiri</h4>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <MapPin size={14} />
                <span>Kadıköy, İstanbul</span>
              </div>
            </div>
            <div className="text-right">
              <span className="inline-block bg-usta-orange/20 text-usta-orange px-3 py-1 rounded-full text-xs font-semibold mb-2 animate-pulse-slow">
                Yolda
              </span>
              <div className="flex items-center gap-1 text-xs text-gray-400">
                <Clock size={12} />
                <span>15 dk</span>
              </div>
            </div>
          </div>
          <div className="mt-4 bg-gray-700 rounded-full h-2 overflow-hidden">
            <div className="bg-gradient-button h-full w-2/3 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
