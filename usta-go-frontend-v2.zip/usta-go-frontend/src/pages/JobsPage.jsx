import React, { useState } from 'react';
import { ChevronLeft, MapPin, Clock, User, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const JobsPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('active');

  const jobs = {
    active: [
      {
        id: 1,
        title: 'Priz Tamiri',
        category: 'Elektrikçi',
        usta: 'Mehmet Yılmaz',
        address: 'Kadıköy, İstanbul',
        status: 'Yolda',
        statusColor: 'orange',
        date: 'Bugün, 15:30',
        price: '250 TL',
        progress: 65
      },
      {
        id: 2,
        title: 'Klima Bakımı',
        category: 'Klima Servisi',
        usta: 'Ali Demir',
        address: 'Beşiktaş, İstanbul',
        status: 'Beklemede',
        statusColor: 'yellow',
        date: 'Yarın, 10:00',
        price: '500 TL',
        progress: 0
      }
    ],
    completed: [
      {
        id: 3,
        title: 'Su Kaçağı Tamiri',
        category: 'Tesisatçı',
        usta: 'Ahmet Kaya',
        address: 'Üsküdar, İstanbul',
        status: 'Tamamlandı',
        statusColor: 'green',
        date: '12 Şubat 2026',
        price: '650 TL',
        rated: true,
        rating: 5
      },
      {
        id: 4,
        title: 'Duvar Boyası',
        category: 'Boyacı',
        usta: 'Mustafa Özkan',
        address: 'Kadıköy, İstanbul',
        status: 'Tamamlandı',
        statusColor: 'green',
        date: '10 Şubat 2026',
        price: '1200 TL',
        rated: false
      }
    ],
    cancelled: [
      {
        id: 5,
        title: 'Montaj İşi',
        category: 'Tadilat',
        usta: 'Hasan Yıldız',
        address: 'Şişli, İstanbul',
        status: 'İptal Edildi',
        statusColor: 'red',
        date: '8 Şubat 2026',
        price: '300 TL',
        cancelReason: 'Müşteri tarafından iptal edildi'
      }
    ]
  };

  const tabs = [
    { id: 'active', label: 'Aktif', count: jobs.active.length },
    { id: 'completed', label: 'Tamamlanan', count: jobs.completed.length },
    { id: 'cancelled', label: 'İptal Edilen', count: jobs.cancelled.length }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Tamamlandı':
        return <CheckCircle className="text-usta-green" size={20} />;
      case 'İptal Edildi':
        return <XCircle className="text-usta-red" size={20} />;
      default:
        return <AlertCircle className="text-usta-orange" size={20} />;
    }
  };

  const getStatusColor = (color) => {
    const colors = {
      orange: 'bg-usta-orange/20 text-usta-orange',
      yellow: 'bg-usta-yellow/20 text-usta-yellow',
      green: 'bg-usta-green/20 text-usta-green',
      red: 'bg-usta-red/20 text-usta-red'
    };
    return colors[color] || colors.orange;
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Elektrikçi': '⚡',
      'Tesisatçı': '🔧',
      'Klima Servisi': '❄️',
      'Boyacı': '🎨',
      'Tadilat': '🔨'
    };
    return icons[category] || '🛠️';
  };

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-4 pt-12 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">İşlerim</h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-button text-white'
                  : 'bg-usta-card/50 text-gray-300 hover:bg-usta-card'
              }`}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                  activeTab === tab.id ? 'bg-white/20' : 'bg-usta-blue/20'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Job Cards */}
      <div className="px-4 space-y-4 animate-fade-in">
        {jobs[activeTab].length === 0 ? (
          <div className="card-dark p-12 text-center">
            <div className="text-6xl mb-4">📋</div>
            <h3 className="text-xl font-bold mb-2">Henüz iş yok</h3>
            <p className="text-gray-400 mb-6">Bu kategoride herhangi bir iş bulunmuyor.</p>
            <button 
              onClick={() => navigate('/')}
              className="btn-primary"
            >
              Yeni İş Bul
            </button>
          </div>
        ) : (
          jobs[activeTab].map((job) => (
            <div
              key={job.id}
              onClick={() => navigate(`/job/${job.id}`)}
              className="card-dark p-4 hover:shadow-2xl transition-all cursor-pointer border-l-4"
              style={{ borderLeftColor: `var(--color-${job.statusColor})` }}
            >
              {/* Header */}
              <div className="flex items-start gap-4 mb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-button flex items-center justify-center text-2xl">
                  {getCategoryIcon(job.category)}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className="font-bold text-lg">{job.title}</h3>
                    {getStatusIcon(job.status)}
                  </div>
                  <p className="text-sm text-gray-400">{job.category}</p>
                </div>
              </div>

              {/* Info */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <User size={16} />
                  <span>{job.usta}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <MapPin size={16} />
                  <span>{job.address}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <Clock size={16} />
                  <span>{job.date}</span>
                </div>
              </div>

              {/* Status & Price */}
              <div className="flex items-center justify-between">
                <span className={`px-4 py-2 rounded-xl text-sm font-semibold ${getStatusColor(job.statusColor)} ${
                  job.status === 'Yolda' ? 'animate-pulse-slow' : ''
                }`}>
                  {job.status}
                </span>
                <span className="text-usta-blue font-bold text-lg">{job.price}</span>
              </div>

              {/* Progress Bar (Only for active jobs) */}
              {job.progress !== undefined && job.progress > 0 && (
                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                    <span>İlerleme</span>
                    <span>{job.progress}%</span>
                  </div>
                  <div className="bg-gray-700 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-gradient-button h-full rounded-full transition-all duration-500"
                      style={{ width: `${job.progress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Rating (For completed jobs) */}
              {job.status === 'Tamamlandı' && !job.rated && (
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    // Rating modal açılacak
                  }}
                  className="w-full mt-4 bg-usta-yellow/20 text-usta-yellow py-3 rounded-xl font-semibold hover:bg-usta-yellow/30 transition-colors"
                >
                  ⭐ Değerlendir
                </button>
              )}

              {/* Cancel Reason */}
              {job.cancelReason && (
                <div className="mt-4 p-3 bg-usta-red/10 border border-usta-red/20 rounded-xl">
                  <p className="text-sm text-usta-red">{job.cancelReason}</p>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default JobsPage;
