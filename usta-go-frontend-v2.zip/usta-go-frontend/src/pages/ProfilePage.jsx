import React from 'react';
import { ChevronLeft, ChevronRight, Star, MapPin, Phone, Mail, Settings, LogOut, HelpCircle, Shield, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ProfilePage = () => {
  const navigate = useNavigate();

  const user = {
    name: 'Ahmet Yılmaz',
    phone: '+90 532 123 45 67',
    email: 'ahmet@example.com',
    location: 'Kadıköy, İstanbul',
    photo: 'https://i.pravatar.cc/150?img=12',
    memberSince: 'Ocak 2026',
    stats: {
      totalJobs: 12,
      activeJobs: 2,
      rating: 4.9,
      savedMoney: '2,400 TL'
    }
  };

  const menuItems = [
    {
      icon: Settings,
      title: 'Hesap Ayarları',
      subtitle: 'Profil bilgilerini düzenle',
      onClick: () => console.log('Ayarlar')
    },
    {
      icon: MapPin,
      title: 'Adreslerim',
      subtitle: 'Kayıtlı adreslerini yönet',
      onClick: () => console.log('Adresler')
    },
    {
      icon: Bell,
      title: 'Bildirimler',
      subtitle: 'Bildirim tercihlerini ayarla',
      onClick: () => console.log('Bildirimler')
    },
    {
      icon: Shield,
      title: 'Gizlilik',
      subtitle: 'Gizlilik ve güvenlik ayarları',
      onClick: () => console.log('Gizlilik')
    },
    {
      icon: HelpCircle,
      title: 'Yardım & Destek',
      subtitle: 'SSS ve iletişim',
      onClick: () => console.log('Yardım')
    },
  ];

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-4 pt-12 pb-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Profil</h1>
        </div>
      </header>

      {/* Profile Card */}
      <div className="px-4 mb-6">
        <div className="card-dark p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <img 
                src={user.photo} 
                alt={user.name}
                className="w-20 h-20 rounded-full object-cover"
              />
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-gradient-button rounded-full flex items-center justify-center shadow-lg">
                <Settings size={14} />
              </button>
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold mb-1">{user.name}</h2>
              <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
                <MapPin size={14} />
                <span>{user.location}</span>
              </div>
              <div className="text-xs text-gray-500">
                Üye: {user.memberSince}
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-3 mb-6">
            <div className="flex items-center gap-3 text-sm">
              <Phone size={16} className="text-usta-blue" />
              <span className="text-gray-300">{user.phone}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Mail size={16} className="text-usta-blue" />
              <span className="text-gray-300">{user.email}</span>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gradient-button/10 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-usta-blue mb-1">{user.stats.totalJobs}</div>
              <div className="text-xs text-gray-400">Toplam İş</div>
            </div>
            <div className="bg-gradient-button/10 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-usta-orange mb-1">{user.stats.activeJobs}</div>
              <div className="text-xs text-gray-400">Aktif İş</div>
            </div>
            <div className="bg-gradient-button/10 rounded-xl p-4 text-center">
              <div className="flex items-center justify-center gap-1 text-2xl font-bold text-usta-yellow mb-1">
                <Star size={20} className="fill-usta-yellow" />
                {user.stats.rating}
              </div>
              <div className="text-xs text-gray-400">Değerlendirme</div>
            </div>
            <div className="bg-gradient-button/10 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-usta-green mb-1">{user.stats.savedMoney}</div>
              <div className="text-xs text-gray-400">Tasarruf</div>
            </div>
          </div>
        </div>
      </div>

      {/* Membership Badge */}
      <div className="px-4 mb-6">
        <div className="bg-gradient-card rounded-2xl p-4 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">👑</span>
              <span className="font-bold">Premium Üyelik</span>
            </div>
            <p className="text-sm text-white/80 mb-3">
              %20 indirim ve öncelikli destek avantajlarından yararlan!
            </p>
            <button className="bg-usta-yellow text-usta-navy font-bold px-6 py-2 rounded-xl text-sm hover:bg-yellow-400 transition-colors">
              Şimdi Yükselt
            </button>
          </div>
          <div className="absolute right-0 top-0 opacity-20 text-9xl">
            ⭐
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-4 mb-6">
        <div className="card-dark overflow-hidden">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={item.onClick}
              className={`w-full flex items-center gap-4 p-4 hover:bg-white/5 transition-colors ${
                index < menuItems.length - 1 ? 'border-b border-gray-700' : ''
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-usta-blue/20 flex items-center justify-center">
                <item.icon size={20} className="text-usta-blue" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-semibold">{item.title}</h4>
                <p className="text-xs text-gray-400">{item.subtitle}</p>
              </div>
              <ChevronRight size={20} className="text-gray-400" />
            </button>
          ))}
        </div>
      </div>

      {/* Logout Button */}
      <div className="px-4">
        <button 
          onClick={() => {
            // Logout işlemi
            console.log('Çıkış yapılıyor...');
            navigate('/');
          }}
          className="w-full bg-usta-red/20 text-usta-red py-4 rounded-2xl font-bold hover:bg-usta-red/30 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut size={20} />
          Çıkış Yap
        </button>
      </div>

      {/* Version Info */}
      <div className="px-4 mt-6 text-center">
        <p className="text-xs text-gray-500">Usta Go v1.0.0</p>
      </div>
    </div>
  );
};

export default ProfilePage;
