import React from 'react';
import { ChevronLeft, Search, MoreVertical } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const MessagesPage = () => {
  const navigate = useNavigate();

  const conversations = [
    {
      id: 1,
      usta: {
        name: 'Mehmet Yılmaz',
        photo: 'https://i.pravatar.cc/150?img=33',
        specialty: 'Elektrikçi'
      },
      lastMessage: 'Adrese 10 dakika içinde varıyorum',
      time: '2 dk',
      unread: 2,
      online: true
    },
    {
      id: 2,
      usta: {
        name: 'Ali Demir',
        photo: 'https://i.pravatar.cc/150?img=12',
        specialty: 'Klima Servisi'
      },
      lastMessage: 'Yarın saat 10:00 uygun mu?',
      time: '15 dk',
      unread: 1,
      online: false
    },
    {
      id: 3,
      usta: {
        name: 'Ahmet Kaya',
        photo: 'https://i.pravatar.cc/150?img=8',
        specialty: 'Tesisatçı'
      },
      lastMessage: 'İş tamamlandı, teşekkürler!',
      time: '2 saat',
      unread: 0,
      online: false
    },
    {
      id: 4,
      usta: {
        name: 'Mustafa Özkan',
        photo: 'https://i.pravatar.cc/150?img=15',
        specialty: 'Boyacı'
      },
      lastMessage: 'Malzeme listesini gönderiyorum',
      time: '1 gün',
      unread: 0,
      online: false
    },
    {
      id: 5,
      usta: {
        name: 'Hasan Yıldız',
        photo: 'https://i.pravatar.cc/150?img=52',
        specialty: 'Tadilat'
      },
      lastMessage: 'Fotoğrafları inceledim, yarın gelebilirim',
      time: '2 gün',
      unread: 3,
      online: true
    }
  ];

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-4 pt-12 pb-6 sticky top-0 bg-gradient-main z-10 backdrop-blur-xl bg-opacity-95">
        <div className="flex items-center gap-4 mb-4">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold flex-1">Mesajlar</h1>
          <button className="w-10 h-10 rounded-full glassmorphism flex items-center justify-center">
            <MoreVertical size={20} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="card-dark p-3 flex items-center gap-3">
          <Search className="text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Usta ara..."
            className="flex-1 bg-transparent outline-none text-white placeholder-gray-400 text-sm"
          />
        </div>
      </header>

      {/* Conversations List */}
      <div className="px-4">
        {conversations.length === 0 ? (
          <div className="card-dark p-12 text-center">
            <div className="text-6xl mb-4">💬</div>
            <h3 className="text-xl font-bold mb-2">Henüz mesaj yok</h3>
            <p className="text-gray-400 mb-6">
              Bir usta ile iş başlattığınızda mesajlaşmaya başlayabilirsiniz.
            </p>
            <button 
              onClick={() => navigate('/')}
              className="btn-primary"
            >
              İş Bul
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {conversations.map((conversation) => (
              <div
                key={conversation.id}
                onClick={() => navigate(`/chat/${conversation.id}`)}
                className="card-dark p-4 hover:shadow-2xl transition-all cursor-pointer animate-fade-in"
              >
                <div className="flex items-center gap-4">
                  {/* Avatar */}
                  <div className="relative">
                    <img 
                      src={conversation.usta.photo} 
                      alt={conversation.usta.name}
                      className="w-14 h-14 rounded-full object-cover"
                    />
                    {conversation.online && (
                      <div className="absolute bottom-0 right-0 w-4 h-4 bg-usta-green rounded-full border-2 border-usta-card"></div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold truncate">{conversation.usta.name}</h3>
                        <p className="text-xs text-gray-400">{conversation.usta.specialty}</p>
                      </div>
                      <span className="text-xs text-gray-400 ml-2">{conversation.time}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <p className={`text-sm truncate flex-1 ${
                        conversation.unread > 0 ? 'text-white font-semibold' : 'text-gray-400'
                      }`}>
                        {conversation.lastMessage}
                      </p>
                      {conversation.unread > 0 && (
                        <div className="ml-2 min-w-[24px] h-6 bg-usta-orange rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold">{conversation.unread}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MessagesPage;
