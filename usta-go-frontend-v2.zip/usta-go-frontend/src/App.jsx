import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import HomePage from './pages/HomePage';
import JobsPage from './pages/JobsPage';
import JobDetailPage from './pages/JobDetailPage';
import ProfilePage from './pages/ProfilePage';
import MessagesPage from './pages/MessagesPage';
import BottomNav from './components/BottomNav';

function AppContent() {
  const location = useLocation();
  
  // Hangi sayfalarda bottom nav gösterilecek
  const showBottomNav = ['/', '/jobs', '/messages', '/profile'].includes(location.pathname);
  
  // Active tab belirleme
  const getActiveTab = () => {
    if (location.pathname === '/') return 'home';
    if (location.pathname.startsWith('/jobs')) return 'jobs';
    if (location.pathname.startsWith('/messages')) return 'messages';
    if (location.pathname.startsWith('/profile')) return 'profile';
    return 'home';
  };

  return (
    <div className="min-h-screen bg-gradient-main">
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/jobs" element={<JobsPage />} />
        <Route path="/job/:id" element={<JobDetailPage />} />
        <Route path="/messages" element={<MessagesPage />} />
        <Route path="/profile" element={<ProfilePage />} />
      </Routes>
      {showBottomNav && <BottomNav active={getActiveTab()} />}
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
