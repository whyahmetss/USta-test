import React from 'react';
import { Home, Briefcase, MessageCircle, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const BottomNav = ({ active = 'home' }) => {
  const navigate = useNavigate();
  
  const navItems = [
    { id: 'home', label: 'Ana Sayfa', icon: Home, path: '/' },
    { id: 'jobs', label: 'İşlerim', icon: Briefcase, badge: 2, path: '/jobs' },
    { id: 'messages', label: 'Mesajlar', icon: MessageCircle, badge: 5, path: '/messages' },
    { id: 'profile', label: 'Profil', icon: User, path: '/profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-usta-navy/95 backdrop-blur-xl border-t border-white/10 pb-safe">
      <div className="max-w-lg mx-auto px-4">
        <div className="flex items-center justify-around h-20">
          {navItems.map((item) => {
            const isActive = active === item.id;
            const Icon = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all ${
                  isActive ? 'text-white' : 'text-gray-400'
                }`}
              >
                <div className="relative">
                  {isActive ? (
                    <div className="w-12 h-12 bg-gradient-button rounded-2xl flex items-center justify-center shadow-lg">
                      <Icon size={24} />
                    </div>
                  ) : (
                    <Icon size={24} />
                  )}
                  {item.badge && !isActive && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-usta-orange rounded-full flex items-center justify-center text-xs font-bold">
                      {item.badge}
                    </div>
                  )}
                </div>
                <span className={`text-xs font-semibold ${isActive ? 'bg-gradient-button bg-clip-text text-transparent' : ''}`}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

export default BottomNav;
