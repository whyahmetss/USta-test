# 🔥 USTA GO - FRONTEND

Modern, profesyonel ev hizmetleri platformu frontend uygulaması.

## 🎨 Özellikler

✅ **Modern Tasarım**
- Mor-mavi gradient arka plan
- Dark theme
- Glassmorphism efektleri
- Yumuşak animasyonlar

✅ **Komponentler**
- Ana Sayfa (kategoriler, popüler servisler)
- Hero banner (%20 indirim)
- Kategori kartları (6 adet)
- Popüler servisler (horizontal scroll)
- Alt navigasyon bar
- Devam eden işler

✅ **Teknolojiler**
- React 18
- Vite
- Tailwind CSS
- React Router
- Lucide Icons

## 🚀 Kurulum

### 1️⃣ Bağımlılıkları Yükle

```bash
npm install
```

### 2️⃣ Geliştirme Sunucusunu Başlat

```bash
npm run dev
```

Tarayıcıda otomatik açılacak: `http://localhost:3000`

### 3️⃣ Production Build

```bash
npm run build
```

Build klasörü `dist/` altında oluşacak.

## 📁 Klasör Yapısı

```
usta-go-frontend/
├── src/
│   ├── components/       # Yeniden kullanılabilir komponentler
│   │   └── BottomNav.jsx
│   ├── pages/           # Sayfa komponentleri
│   │   └── HomePage.jsx
│   ├── App.jsx          # Ana uygulama
│   ├── main.jsx         # Giriş noktası
│   └── index.css        # Global stiller
├── public/              # Statik dosyalar
├── index.html           # HTML template
├── package.json
├── tailwind.config.js   # Tailwind ayarları
└── vite.config.js       # Vite ayarları
```

## 🎨 Renk Paleti

- **Ana Renk:** #1E3A8A (Koyu Mavi)
- **İkincil:** #3B82F6 (Elektrik Mavisi)
- **Vurgu:** #7C3AED (Mor)
- **Aksan:** #FF6B35 (Turuncu)
- **Başarı:** #10B981 (Yeşil)

## 🔧 Geliştirme

### Yeni Sayfa Eklemek

1. `src/pages/` altında yeni JSX dosyası oluştur
2. `App.jsx` içinde route ekle:

```jsx
<Route path="/yeni-sayfa" element={<YeniSayfa />} />
```

### Yeni Komponent Eklemek

1. `src/components/` altında yeni JSX dosyası oluştur
2. İhtiyaç duyulan sayfada import et

## 📱 Responsive

Mobil-first tasarım:
- Mobil: Varsayılan
- Tablet: `md:` prefix
- Desktop: `lg:` prefix

## 🎯 Yapılacaklar

- [ ] İş Listesi sayfası
- [ ] İş Detay sayfası
- [ ] Profil sayfası
- [ ] Mesajlar sayfası
- [ ] Backend entegrasyonu
- [ ] Authentication

## 💡 İpuçları

- Hot reload aktif, değişiklikler otomatik yansır
- Tailwind class'ları kullan (inline styles yerine)
- Komponentleri küçük ve yeniden kullanılabilir tut
- Animasyonlar için `animate-` class'larını kullan

## 🐛 Sorun Giderme

**Port zaten kullanımda:**
```bash
# vite.config.js içinde port değiştir
server: { port: 3001 }
```

**Tailwind çalışmıyor:**
```bash
# PostCSS ve Tailwind'i yeniden yükle
npm install -D tailwindcss postcss autoprefixer
```

## 📞 Yardım

Sorun yaşarsan:
1. `node_modules/` sil
2. `npm install` yap
3. `npm run dev` çalıştır

---

**Başarılar!** 🚀
